<?php

return [

    'id' => '#',
    'operations' => 'Operations',
    'title' => 'Categories',
    'categoryName' => 'Name',
    'categoryNameAr' => 'Name AR',
    'categoryImage' => 'Image',
    'type_id' => 'Main type',
    'created_at' => 'Created at',
    'updated_at' => 'Updated at',


    'name' => 'Name',
    'image_url' => 'Image',
    'type' => 'Main type',

];