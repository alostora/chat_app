<?php

return [

    'id' => '#',
    'operations' => 'Operations',
    'title' => 'Brands',
    'brandName' => 'Name',
    'brandNameAr' => 'Name AR',
    'brandImage' => 'Image',
    'created_at' => 'Created at',
    'updated_at' => 'Updated at',


    
    'name' => 'Name',
    'image_url' => 'Image',
    'type' => 'Main type',
];