<?php

return [

    'id' => '#',
    'operations' => 'Operations',
    'title' => 'Permissions',
    'permissionName' => 'Name',
    'permissionNameAr' => 'Name AR',
    'created_at' => 'Created at',
    'updated_at' => 'Updated at',
    'name' => 'Name',

];
