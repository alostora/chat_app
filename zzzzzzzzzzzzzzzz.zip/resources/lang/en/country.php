<?php

return [

    'id' => '#',
    'operations' => 'Operations',
	'title' => 'Countries',
	'countryName' => 'Name',
    'countryNameAr' => 'Name AR',
    'countryPhoneKey' => 'Phone key',
    'countryCode' => 'National code',
    'countryFlag' => 'Flag',
    'countryCurrency' => 'Currency',
    'created_at' => 'Created at',
    'updated_at' => 'Updated at',

    

    'name' => 'Name',
    'image_url' => 'Image',
];

