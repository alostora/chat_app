<?php

return [

    'id' => '#',
    'operations' => 'Operations',
    'title' => 'Users',
    'name' => 'Name',
    'email' => 'Email',
    'phone' => 'Phone',
    'image' => 'Image',
    'gender' => 'Gender',
    'birthDate' => 'Birth date',
    'password' => 'Password',
    'confirm_password' => 'Confirm password',


    
    'name' => 'Name',
    'image_url' => 'Image',
    'type' => 'Main type',


    "bio" => "Biography",
    "last_login_at" => "Last login",
    "online" => "Online",
    "country_key" => "Country key",
    "country" => "Country",



];