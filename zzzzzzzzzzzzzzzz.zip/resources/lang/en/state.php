<?php

return [
	
    'id' => '#',
    'operations' => 'Operations',
	'title' => 'States',
	'stateName' => 'Name',
	'stateNameAr' => 'Name Ar',
	'city_id' => 'City',
	'country_id' => 'Country',
    'created_at' => 'Created at',
    'updated_at' => 'Updated at',


    
    'name' => 'Name',
    'image_url' => 'Image',
    'type' => 'Main type',

	'country' => 'Country',
	'city' => 'City',

    
];