<?php

return [

    'id' => '#',
    'operations' => 'Operations',
    'title' => 'Cities',
    'cityName' => 'Name',
    'cityNameAr' => 'Name AR',
    'country_id' => 'Country',
    'created_at' => 'Created at',
    'updated_at' => 'Updated at',



    'name' => 'Name',
    'country_name' => 'Name',






];
