<?php

return [

	'online' => 'online',
	'Control Panel' => 'Control Panel',
	'Admins' => 'Admins',
	'Users' => 'Users',
	'Categories' => 'Categories',
	'Setting' => 'Setting',
	'Countries' => 'Countries',
	'Cities' => 'Cities',
	'States' => 'States',
	'Brands' => 'Brands',
	'S_categories' => 'Sub categories',
	'Colors' => 'Colors',
	'Sizes' => 'Sizes',
	'MeasurUnits' => 'Measur units',
	'MainTypes' => 'Main types',
	'Items' => 'Items',
	'Vendors' => 'Vendors',
	'Permissions' => 'Permissions',
	'Roles' => 'Roles',
	'Langauges' => 'Langauges',

];