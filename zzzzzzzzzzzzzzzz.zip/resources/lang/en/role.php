<?php

return [

    'id' => '#',
    'operations' => 'Operations',
    'title' => 'Roles',
    'roleName' => 'Name',
    'roleNameAr' => 'Name AR',
    'created_at' => 'Created at',
    'updated_at' => 'Cpdated at',

    'name' => 'Name',
];
