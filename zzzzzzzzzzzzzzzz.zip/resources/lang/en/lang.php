<?php

return [

    'id' => '#',
    'operations' => 'Operations',
    'title' => 'Colors',
    'langName' => 'Name',
    
    'langCode' => 'langCode',
    'created_at' => 'Created at',
    'updated_at' => 'Cpdated at',

    'name' => 'Name',
    'code' => 'Code',
];
