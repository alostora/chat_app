<?php

return [

    'id' => '#',
    'operations' => 'Operations',
    'title' => 'Vendors',
    'name' => 'Name',
    'email' => 'Email',
    'phone' => 'Phone',
    'image' => 'Image',
    'gender' => 'Gender',
    'birthDate' => 'Birth date',
    'password' => 'Password',
    'confirm_password' => 'Confirm password',


    
    'name' => 'Name',
    'image_url' => 'Image',
    'type' => 'Main type',



];