<?php

return [
    'id' => '#',
    'operations' => 'Operations',
	'title' => 'Setting',
	'siteName' => 'Name',
	'siteNameAr' => 'Name AR',
	'siteEmail' => 'Email',
	'siteMobile' => 'Mobile',
	'sitePhone' => 'Phone',
	'siteDesc' => 'Descreption',
	'siteDescAr' => 'Descreption AR',
	'siteImage' => 'Image',
	'siteLogo' => 'Logo',
	'is_live' => 'Live',
    'created_at' => 'Created at',
    'updated_at' => 'Cpdated at',

    
    'name' => 'Name',
	'desc' => 'Descreption',
    'image_url' => 'Image',
    'type' => 'Main type',

];

