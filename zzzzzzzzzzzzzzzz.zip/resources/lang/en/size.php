<?php

return [

    'id' => '#',
    'operations' => 'Operations',
    'title' => 'Sizes',
    'sizeName' => 'Name',
    'sizeNameAr' => 'Name AR',
    'type_id' => 'Type',
    'sizeValue' => 'Value',
    'created_at' => 'Created at',
    'updated_at' => 'Updated at',

    
    'name' => 'Name',
    'image_url' => 'Image',
    'type' => 'Main type',
    'main_type' => 'Main type',


];
