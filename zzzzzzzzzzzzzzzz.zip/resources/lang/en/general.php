<?php

return [


    'created_at' => 'Created at',
    'updated_at' => 'Updated at',
    'deleted_at' => 'Deleted at',


    'create' => 'Create',
    'update' => 'Update',
    'delete' => 'Delete',


    'add' => 'Add',
    'edit' => 'Edit',
    'remove' => 'Remove',

    'accepte' => 'Accept',
    'reject' => 'Reject',

    'waiting' => 'Waiting',
    'save' => 'Save',
    'send' => 'Send',
    'all' => 'All',
    'choose' => 'Choose',


    'data' => 'Data',
    'info' => 'Informations',
    
    'login' => 'Log in',
    'register' => 'Register',
    'already_have_account' => 'Already have account',
    'home' => 'home',
    'dash_board' => 'Dash board',
    'control_panel' => 'Control panel',

    'forget_pass' => 'Forget password',
    'remember_me' => 'Remember me',
    'name' => 'Name',
    'email' => 'Email',
    'password' => 'Password',
    'confirme_ password' => 'Confirme password',
    'logout' => 'Log out',
    'admins' => 'Admins',
    'users' => 'Users',






    //categories sizes
    'clothes' => 'Clothes',
    'shoes' => 'Shoes',
    'other' => 'Other',


    //measurment units
    'tall'          => 'Tall',
    'weight'        => 'Weight',
    'liquid'        => 'Liquid',

    
    'name' => 'Name',
    'image_url' => 'Image',
    'type' => 'Main type',





];