<?php

return [

    'id' => '#',
    'operations' => 'Operations',
    'title' => 'Admins',
    'name' => 'Name',
    'email' => 'Email',
    'password' => 'Password',
    'confirm_password' => 'Confirm password',
    'permissions' => 'Permissions',
    'created_at' => 'Created at',
    'updated_at' => 'Updated at',
];