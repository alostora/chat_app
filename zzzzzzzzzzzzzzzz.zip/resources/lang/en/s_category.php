<?php

return [

    'id' => '#',
    'operations' => 'Operations',
    'title' => 'Sub categories',
    'categoryName' => 'Name',
    'categoryNameAr' => 'Name AR',
    'categoryImage' => 'Image',
    'cat_id' => 'Main category',
    'created_at' => 'Created at',
    'updated_at' => 'Updated at',


    'main_category' => 'Main category',
    
    'name' => 'Name',
    'image_url' => 'Image',
    'type' => 'Main type',

];