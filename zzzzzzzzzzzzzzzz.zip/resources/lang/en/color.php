<?php

return [

    'id' => '#',
    'operations' => 'Operations',
    'title' => 'Colors',
    'colorName' => 'Name',
    'colorNameAr' => 'Name AR',
    'colorCode' => 'Code',
    'created_at' => 'Created at',
    'updated_at' => 'Cpdated at',

    'name' => 'Name',
    'code' => 'Code',
];
