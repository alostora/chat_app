<?php

return [

    'id' => '#',
    'operations' => 'Operations',
    'title' => 'Measur types',
    'typeName' => 'Name',
    'typeNameAr' => 'Name AR',
    'created_at' => 'Created at',
    'updated_at' => 'Updated at',



    
    'name' => 'Name',
    'image_url' => 'Image',
    'type' => 'Main type',


];
