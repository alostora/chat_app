<?php

return [

    'id' => '#',
    'operations'    => 'Operations',
    'title'         => 'Measur units',
    'unitName'      => 'Name',
    'unitNameAr'    => 'Name AR',
    'unitType'      => 'Type',
    'unitCode'      => 'Code',
    'created_at'    => 'Created at',
    'updated_at'    => 'Updated at',


    
    
    'name' => 'Name',
    'image_url' => 'Image',
    'type' => 'Main type',


];
