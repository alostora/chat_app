<div class="content-wrapper">
	<section class="content">
		<div class="row">
	        <div class="col-xs-12">
				<div class="box box-info">
				    @include('Admin/layouts/errorMessages')